﻿using Quizzit.Models;
using Quizzit.ViewModel;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Quizzit.Controllers
{
    public partial class HomeController : Controller
    {
        [NonAction]
        public void LoadQuestions()
        {
            List<QuestionVM> qVms = new List<QuestionVM>();
            //
            var questions = db.Questions.ToList();
            foreach (var question in questions)
            {
                if (question != null)
                {
                    var qOptions = db.QuestionAnswers.
                        Where(x => x.QuestionID == question.ID)
                        .Select(x => new QuestionOptionVM()
                        {
                            Option = x.AnswerText,
                            IsAnswer = false
                        }).ToList();
                    //
                    QuestionVM qVm = new QuestionVM();
                    qVm.ID = question.ID;
                    qVm.QuestionText = question.QuestionText;
                    qVm.QuestionType = question.QuestionType;
                    qVm.Options = qOptions;
                    qVm.NextQuestion = question.NextQuestionID;
                    //
                    qVms.Add(qVm);
                }
            }
            Session["Questions"] = qVms;
        }
    }

    public partial class HomeController : Controller
    {
        QuizzitEntities db = new QuizzitEntities();

        public ActionResult Index(int? qid)
        {
            if (Session["Questions"] == null)
            {
                LoadQuestions();
            }
            //
            QuestionVM question = null;
            //
            if (qid.HasValue == false)
            {
                question = (Session["Questions"] as List<QuestionVM>).FirstOrDefault();
                if (question == null)
                {
                    return Content("No questions exits in the database");
                }
                //
                ViewBag.Question = question;
                return View();
            }
            else
            {
                if (qid == int.MinValue)
                {
                    return RedirectToAction("Summary");
                }
                else
                {
                    question = (Session["Questions"] as List<QuestionVM>).Where(x => x.ID == qid).FirstOrDefault();
                    if (question == null)
                    {
                        return Content("Invalid next question id !!");
                    }
                    //
                    ViewBag.Question = question;
                    return View();
                }
            }
        }

        public ActionResult Summary()
        {
            return Content("This is summary");
        }

        //public JsonResult NextQuestion(int questionId)
        //{
        //    var question = db.Questions.Find(questionId);
        //    if (question != null)
        //    {
        //        var qOptions = db.QuestionAnswers.
        //            Where(x => x.QuestionID == question.ID)
        //            .Select(x => new QuestionOptionVM()
        //            {
        //                Option = x.AnswerText,
        //                IsAnswer = false
        //            }).ToList();
        //        //
        //        QuestionVM qVm = new QuestionVM();
        //        qVm.QuestionText = question.QuestionText;
        //        qVm.QuestionType = question.QuestionType;
        //        qVm.Options = qOptions;
        //        qVm.NextQuestion = question.NextQuestionID;
        //        //
        //        return Json(new { status = true, question = qVm });
        //    }
        //    return Json(new { status = false });
        //}

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
        }

    }
}