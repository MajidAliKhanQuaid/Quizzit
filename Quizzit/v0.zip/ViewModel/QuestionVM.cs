﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Quizzit.ViewModel
{
    public class QuestionVM
    {
        public int ID { get; set; }
        public string QuestionText { get; set; }
        public int QuestionType { get; set; }
        public List<QuestionOptionVM> Options { get; set; }
        public int? NextQuestion { get; set; }
    }
}