﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Quizzit.ViewModel
{
    public class QuestionOptionVM
    {
        public string Option { get; set; }
        public bool IsAnswer { get; set; }
    }
}